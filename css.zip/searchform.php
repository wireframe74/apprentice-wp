
<form action="<?php bloginfo('siteurl'); ?>" id="searchform" method="get">
<input type="text" value="SEARCH KEYWORDS" name="s" class="publicationsearch" placeholder="SEARCH KEYWORDS"'. $onfocus . $onblur .' />
<input type="submit"  style="display:none;" value="'. $button_text .'" />
</form>