 <ul class="main-menu-list container">

                           <li class="main home"><a href="#">Home</a></li>
                            <li class="main">
                              <a href="#" class="main-link" rel="menuitem">Apprentices</a>
                             

                              <div class="megamenu" aria-hidden="true"> 
                                <div class="container">
                                <ul class="megamenu--sub-menu">
                                     <li><a href="#">Apprentices</a></li>
                                     <li><a href="#">Benefits of Apprenticeship</a></li>
                                     <li><a href="#">Becoming an apprentice/trainee</a></li>
                                     <li><a href="#">FAQs about apprenticeship</a></li>
                                     <li><a href="#">Safety Info and Policies</a></li>
                                     <li><a href="#">Apprentices Qualifications &amp; Training</a></li>
                                     <li><a href="#">Show me the money</a></li>
                                     <li><a href="#">Useful Links</a></li>
                                     <li><a href="#">Where to now?</a></li>
                                     <li><a href="#">Support Assistance Programmes</a></li>
                                     <li><a href="#">Tool Kits</a></li>
                                     <li><a href="#">Job Seekers</a></li>
                                 </ul>
                                 </div>
                              </div> <!-- end megamenu -->


                            </li>
                           <li class="main">
                              <a href="#" class="main-link" rel="menuitem">Employers</a>
                                

                                <div class="megamenu" aria-hidden="true"> 
                                <div class="container">
                                <ul class="megamenu--sub-menu">
                                     <li><a href="#">Employers</a></li>
                                     <li><a href="#">Benefits of an apprenticeship</a></li>
                                     <li><a href="#">Info on Apprenticeships</a></li>
                                    <li><a href="#"> Safety Info and Policies</a></li>
                                     <li><a href="#">How we can help your business</a></li>
                                     <li><a href="#">Productivity Centre</a></li>
                                     <li><a href="#">Apprentice Training</a></li>
                                     <li><a href="#">Training and Workforce Development</a></li>
                                 </ul>
                                 </div>
                              </div> <!-- end megamenu -->
                            </li>


                               <li class="main">
                              <a href="#" class="main-link" rel="menuitem">About</a>
                                       <div class="megamenu" aria-hidden="true"> 
                                <div class="container">
                                <ul class="megamenu--sub-menu">
                                    <li><a href="#">Our History</a></li>
                                    <li><a href="#">Our Difference</a></li>
                                    <li><a href="#">News</a></li>
                                 </ul>
                                 </div>
                              </div> <!-- end megamenu -->


                            </li>


                            <!-- <li class="main" rel="menuitem"><a href="#">Another link</a></li>
                            <li class="main" rel="menuitem"><a href="#">Another link</a></li>
                            <li class="main" rel="menuitem"><a href="#">Another link</a></li> -->
                          </ul>