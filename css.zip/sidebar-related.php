<?php
/**
 * The sidebar containing the main widget area
 *
 
 */

?>

	<?php dynamic_sidebar('sidebar-related'); ?>