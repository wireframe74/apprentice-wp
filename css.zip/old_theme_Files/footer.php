 </div>
<div id="aigwd-footerWidgets">
  <div id="footerWidgetsContainer">
    <div class="aigwd-footerarea1">
    <?php // FOOTER AWARDS MENU
		if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Widget 1') ) : ?>
      <?php endif; ?></div>
    <div class="aigwd-footerarea2">
    <?php // FOOTER AWARDS MENU
		if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Widget 2') ) : ?>
      <?php endif; ?>
    </div>
	<div class="aigwd-footerarea3">
    <?php // FOOTER AWARDS MENU
		if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Widget 3') ) : ?>
      <?php endif; ?>
    </div>
    <div class="aigwd-footerarea4">
    <?php // FOOTER AWARDS MENU
		if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Widget 4') ) : ?>
      <?php endif; ?>
      </div>
  </div>
  
  <div id="aigwd-footerWidgets2">
  <div id="footerWidgetsContainer2">
    <div class="aigwd-footerareab1">
    <?php // FOOTER AWARDS MENU
		if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Bottom Footer Widget 1') ) : ?>
      <?php endif; ?>
    </div>
    <div class="aigwd-footerareab2">
    <?php // FOOTER AWARDS MENU
		if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Bottom Footer Widget 2') ) : ?>
      <?php endif; ?>
    </div>
	<div class="aigwd-footerareab3">
    <?php // FOOTER AWARDS MENU
		if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Bottom Footer Widget 3') ) : ?>
      <?php endif; ?>
    </div>
    
  </div>
  
  </div></div>
  <!-- / OVERALL CONTAINER TAG --></div>

  <?php wp_footer(); ?>
 
</body></html>