=== reSpare ===
Theme Name: reSpare
Author: Matthew Trevino
Author URI: http://onebillionwords.com
Description: Based on Bare, originally released in 2006, reSpare has been updated to be responsive, include 2 widget areas, and has had its code rewritten to be compliant with current versions of Wordpress.
Version: 2.6
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: white, light, blue, one-column, featured-images, flexible-width, threaded-comments
Text Domain: reSpare