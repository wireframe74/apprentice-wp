<div id="st-accordion" class="st-accordion">
<ul>

		<?php if ( get_post_meta($post->ID, 'sh_anchor1header', true) ) : ?>
		<li>
		<a href="#"><?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor1header', true)); ?><span class="st-arrow">Open or Close</span></a>
		<div class="st-content">
		<?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor1', true));  ?>
		</div>
		</li>
		<?php endif; ?>


		<?php if ( get_post_meta($post->ID, 'sh_anchor2header', true) ) : ?>
		<li>
		<a href="#"><?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor2header', true)); ?><span class="st-arrow">Open or Close</span></a>
		<div class="st-content">
		<?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor2', true));  ?>
		</div>
		</li>
		<?php endif; ?>

		<?php if ( get_post_meta($post->ID, 'sh_anchor3header', true) ) : ?>
		<li>
		<a href="#"><?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor3header', true)); ?><span class="st-arrow">Open or Close</span></a>
		<div class="st-content">
		<?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor3', true));  ?>
		</div>
		</li>
		<?php endif; ?>

		<?php if ( get_post_meta($post->ID, 'sh_anchor4header', true) ) : ?>
		<li>
		<a href="#"><?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor4header', true)); ?><span class="st-arrow">Open or Close</span></a>
		<div class="st-content">
		<?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor4', true));  ?>
		</div>
		</li>
		<?php endif; ?>

		<?php if ( get_post_meta($post->ID, 'sh_anchor5header', true) ) : ?>
		<li>
		<a href="#"><?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor5header', true)); ?><span class="st-arrow">Open or Close</span></a>
		<div class="st-content">
		<?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor5', true));  ?>
		</div>
		</li>
		<?php endif; ?>

		<?php if ( get_post_meta($post->ID, 'sh_anchor6header', true) ) : ?>
		<li>
		<a href="#"><?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor6header', true)); ?><span class="st-arrow">Open or Close</span></a>
		<div class="st-content">
		<?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor6', true));  ?>
		</div>
		</li>
		<?php endif; ?>

		<?php if ( get_post_meta($post->ID, 'sh_anchor7header', true) ) : ?>
		<li>
		<a href="#"><?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor7header', true)); ?><span class="st-arrow">Open or Close</span></a>
		<div class="st-content">
		<?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor7', true));  ?>
		</div>
		</li>
		<?php endif; ?>

		<?php if ( get_post_meta($post->ID, 'sh_anchor8header', true) ) : ?>
		<li>
		<a href="#"><?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor8header', true)); ?><span class="st-arrow">Open or Close</span></a>
		<div class="st-content">
		<?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor8', true));  ?>
		</div>
		</li>
		<?php endif; ?>

		<?php if ( get_post_meta($post->ID, 'sh_anchor9header', true) ) : ?>
		<li>
		<a href="#"><?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor9header', true)); ?><span class="st-arrow">Open or Close</span></a>
		<div class="st-content">
		<?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor9', true));  ?>
		</div>
		</li>
		<?php endif; ?>

		<?php if ( get_post_meta($post->ID, 'sh_anchor10header', true) ) : ?>
		<li>
		<a href="#"><?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor10header', true)); ?><span class="st-arrow">Open or Close</span></a>
		<div class="st-content">
		<?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor10', true));  ?>
		</div>
		</li>
		<?php endif; ?>

		<?php if ( get_post_meta($post->ID, 'sh_anchor11header', true) ) : ?>
		<li>
		<a href="#"><?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor11header', true)); ?><span class="st-arrow">Open or Close</span></a>
		<div class="st-content">
		<?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor11', true));  ?>
		</div>
		</li>
		<?php endif; ?>

		<?php if ( get_post_meta($post->ID, 'sh_anchor12header', true) ) : ?>
		<li>
		<a href="#"><?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor12header', true)); ?><span class="st-arrow">Open or Close</span></a>
		<div class="st-content">
		<?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor12', true));  ?>
		</div>
		</li>
		<?php endif; ?>

		<?php if ( get_post_meta($post->ID, 'sh_anchor13header', true) ) : ?>
		<li>
		<a href="#"><?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor13header', true)); ?><span class="st-arrow">Open or Close</span></a>
		<div class="st-content">
		<?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor13', true));  ?>
		</div>
		</li>
		<?php endif; ?>

		<?php if ( get_post_meta($post->ID, 'sh_anchor14header', true) ) : ?>
		<li>
		<a href="#"><?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor14header', true)); ?><span class="st-arrow">Open or Close</span></a>
		<div class="st-content">
		<?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor14', true));  ?>
		</div>
		</li>
		<?php endif; ?>

		<?php if ( get_post_meta($post->ID, 'sh_anchor15header', true) ) : ?>
		<li>
		<a href="#"><?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor15header', true)); ?><span class="st-arrow">Open or Close</span></a>
		<div class="st-content">
		<?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor15', true));  ?>
		</div>
		</li>
		<?php endif; ?>

		<?php if ( get_post_meta($post->ID, 'sh_anchor16header', true) ) : ?>
		<li>
		<a href="#"><?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor16header', true)); ?><span class="st-arrow">Open or Close</span></a>
		<div class="st-content">
		<?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor16', true));  ?>
		</div>
		</li>
		<?php endif; ?>

		<?php if ( get_post_meta($post->ID, 'sh_anchor17header', true) ) : ?>
		<li>
		<a href="#"><?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor17header', true)); ?><span class="st-arrow">Open or Close</span></a>
		<div class="st-content">
		<?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor17', true));  ?>
		</div>
		</li>
		<?php endif; ?>

		<?php if ( get_post_meta($post->ID, 'sh_anchor18header', true) ) : ?>
		<li>
		<a href="#"><?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor18header', true)); ?><span class="st-arrow">Open or Close</span></a>
		<div class="st-content">
		<?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor18', true));  ?>
		</div>
		</li>
		<?php endif; ?>

		<?php if ( get_post_meta($post->ID, 'sh_anchor19header', true) ) : ?>
		<li>
		<a href="#"><?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor19header', true)); ?><span class="st-arrow">Open or Close</span></a>
		<div class="st-content">
		<?php echo do_shortcode (get_post_meta($post->ID, 'sh_anchor19', true));  ?>
		</div>
		</li>
		<?php endif; ?>


</ul>
</div>

                      