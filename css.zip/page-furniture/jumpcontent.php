<? // ************* ANCHOR 1 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor1', true) )   
		echo'<div class="anchor"><a id="anchor1"></a>';
		
		if ( get_post_meta($post->ID, 'sh_anchor1header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor1header', true));
		if ( get_post_meta($post->ID, 'sh_anchor1header', true) )  
		echo '</h2>'; 
		
		
		if ( get_post_meta($post->ID, 'sh_anchor1', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor1', true));
		// set the scrollable area content
   			if ( get_post_meta($post->ID, 'sh_anchor1', true) )   
			echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';

	// ************* ANCHOR 2 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor2', true) )   
		echo'<div class="anchor"><a id="anchor2"></a>';	
			
		if ( get_post_meta($post->ID, 'sh_anchor2header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor2header', true));
		if ( get_post_meta($post->ID, 'sh_anchor2header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor2', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor2', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor2', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 3 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor3', true) )   
		echo'<div class="anchor"><a id="anchor3"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor3header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor3header', true));
		if ( get_post_meta($post->ID, 'sh_anchor3header', true) )  
		echo '</h2>'; 
		
		
		if ( get_post_meta($post->ID, 'sh_anchor3', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor3', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor3', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 4 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor4', true) )   
		echo'<div class="anchor"><a id="anchor4"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor4header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor4header', true));
		if ( get_post_meta($post->ID, 'sh_anchor4header', true) )  
		echo '</h2>'; 
		
		
		
		if ( get_post_meta($post->ID, 'sh_anchor4', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor4', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor4', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 5 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor5', true) )   
		echo'<div class="anchor"><a id="anchor5"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor5header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor5header', true));
		if ( get_post_meta($post->ID, 'sh_anchor5header', true) )  
		echo '</h2>'; 
		
		
		if ( get_post_meta($post->ID, 'sh_anchor5', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor5', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor5', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 6 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor6', true) )   
		echo'<div class="anchor"><a id="anchor6"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor6header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor6header', true));
		if ( get_post_meta($post->ID, 'sh_anchor6header', true) )  
		echo '</h2>'; 
		
		
		if ( get_post_meta($post->ID, 'sh_anchor6', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor6', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor6', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 7 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor7', true) )   
		echo'<div class="anchor"><a id="anchor7"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor7header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor7header', true));
		if ( get_post_meta($post->ID, 'sh_anchor7header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor7', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor7', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor7', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 8 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor8', true) )   
		echo'<div class="anchor"><a id="anchor8"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor8header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor8header', true));
		if ( get_post_meta($post->ID, 'sh_anchor8header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor8', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor8', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor8', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 9 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor9', true) )   
		echo'<div class="anchor"><a id="anchor9"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor9header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor9header', true));
		if ( get_post_meta($post->ID, 'sh_anchor9header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor9', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor9', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor9', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 10 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor10', true) )   
		echo'<div class="anchor"><a id="anchor10"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor10header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor10header', true));
		if ( get_post_meta($post->ID, 'sh_anchor10header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor10', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor10', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor10', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 11 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor11', true) )   
		echo'<div class="anchor"><a id="anchor11"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor11header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor10header', true));
		if ( get_post_meta($post->ID, 'sh_anchor11header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor11', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor11', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor11', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 12 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor12', true) )   
		echo'<div class="anchor"><a id="anchor12"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor12header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor12header', true));
		if ( get_post_meta($post->ID, 'sh_anchor12header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor12', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor12', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor12', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 13 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor13', true) )   
		echo'<div class="anchor"><a id="anchor13"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor13header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor13header', true));
		if ( get_post_meta($post->ID, 'sh_anchor13header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor13', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor13', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor13', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 14 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor14', true) )   
		echo'<div class="anchor"><a id="anchor14"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor14header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor14header', true));
		if ( get_post_meta($post->ID, 'sh_anchor14header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor14', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor14', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor14', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 15 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor15', true) )   
		echo'<div class="anchor"><a id="anchor15"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor15header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor15header', true));
		if ( get_post_meta($post->ID, 'sh_anchor15header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor15', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor15', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor15', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 16 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor16', true) )   
		echo'<div class="anchor"><a id="anchor16"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor16header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor16header', true));
		if ( get_post_meta($post->ID, 'sh_anchor16header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor16', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor16', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor16', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 170 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor17', true) )   
		echo'<div class="anchor"><a id="anchor17"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor17header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor17header', true));
		if ( get_post_meta($post->ID, 'sh_anchor17header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor17', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor17', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor17', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 18 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor18', true) )   
		echo'<div class="anchor"><a id="anchor18"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor18header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor18header', true));
		if ( get_post_meta($post->ID, 'sh_anchor18header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor18', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor18', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor18', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 19 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor19', true) )   
		echo'<div class="anchor"><a id="anchor19"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor19header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor19header', true));
		if ( get_post_meta($post->ID, 'sh_anchor19header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor19', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor19', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor19', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 20 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor20', true) )   
		echo'<div class="anchor"><a id="anchor20"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor20header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor20header', true));
		if ( get_post_meta($post->ID, 'sh_anchor20header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor20', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor20', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor20', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
	?>		 