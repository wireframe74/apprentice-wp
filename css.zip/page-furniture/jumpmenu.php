<?php echo '<ul id="jump">';
	
	// ANCHOR 1 LI
    if ( get_post_meta($post->ID, 'sh_anchor1header', true) )  
	echo '<li><a href="#anchor1" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor1header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor1header', true));
	if ( get_post_meta($post->ID, 'sh_anchor1header', true) ) 
	echo '</a></li>';
	
		// ANCHOR 2 LI
    if ( get_post_meta($post->ID, 'sh_anchor2header', true) )  
	echo '<li><a href="#anchor2"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor2header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor2header', true));
	if ( get_post_meta($post->ID, 'sh_anchor2header', true) ) 
	echo '</a></li>';
	
			// ANCHOR 3 LI
    if ( get_post_meta($post->ID, 'sh_anchor3header', true) )  
	echo '<li><a href="#anchor3"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor3header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor3header', true));
	if ( get_post_meta($post->ID, 'sh_anchor3header', true) ) 
	echo '</a></li>';

			// ANCHOR 4 LI
    if ( get_post_meta($post->ID, 'sh_anchor4header', true) )  
	echo '<li><a href="#anchor4"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor4header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor4header', true));
	if ( get_post_meta($post->ID, 'sh_anchor4header', true) ) 
	echo '</a></li>';

			
			// ANCHOR 5 LI
    if ( get_post_meta($post->ID, 'sh_anchor5header', true) )  
	echo '<li><a href="#anchor5"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor5header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor5header', true));
	if ( get_post_meta($post->ID, 'sh_anchor5header', true) ) 
	echo '</a></li>';

 
			// ANCHOR 6 LI
    if ( get_post_meta($post->ID, 'sh_anchor6header', true) )  
	echo '<li><a href="#anchor6"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor6header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor6header', true));
	if ( get_post_meta($post->ID, 'sh_anchor6header', true) ) 
	echo '</a></li>';


				// ANCHOR 7 LI
    if ( get_post_meta($post->ID, 'sh_anchor7header', true) )  
	echo '<li><a href="#anchor7"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor7header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor7header', true));
	if ( get_post_meta($post->ID, 'sh_anchor7header', true) ) 
	echo '</a></li>';

	
			// ANCHOR 8 LI
    if ( get_post_meta($post->ID, 'sh_anchor8header', true) )  
	echo '<li><a href="#anchor8"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor8header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor8header', true));
	if ( get_post_meta($post->ID, 'sh_anchor8header', true) ) 
	echo '</a></li>';

  
				// ANCHOR 9 LI
    if ( get_post_meta($post->ID, 'sh_anchor9header', true) )  
	echo '<li><a href="#anchor9"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor9header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor9header', true));
	if ( get_post_meta($post->ID, 'sh_anchor9header', true) ) 
	echo '</a></li>';

				
			// ANCHOR 10 LI
    if ( get_post_meta($post->ID, 'sh_anchor10header', true) )  
	echo '<li><a href="#anchor10"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor10header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor10header', true));
	if ( get_post_meta($post->ID, 'sh_anchor10header', true) ) 
	echo '</a></li>';
	
	// ANCHOR 11 LI
    if ( get_post_meta($post->ID, 'sh_anchor11header', true) )  
	echo '<li><a href="#anchor11"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor11header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor11header', true));
	if ( get_post_meta($post->ID, 'sh_anchor11header', true) ) 
	echo '</a></li>';
	
		// ANCHOR 12 LI
    if ( get_post_meta($post->ID, 'sh_anchor12header', true) )  
	echo '<li><a href="#anchor12"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor12header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor12header', true));
	if ( get_post_meta($post->ID, 'sh_anchor12header', true) ) 
	echo '</a></li>';
	
			// ANCHOR 13 LI
    if ( get_post_meta($post->ID, 'sh_anchor13header', true) )  
	echo '<li><a href="#anchor13"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor13header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor13header', true));
	if ( get_post_meta($post->ID, 'sh_anchor13header', true) ) 
	echo '</a></li>';

			// ANCHOR 14 LI
    if ( get_post_meta($post->ID, 'sh_anchor14header', true) )  
	echo '<li><a href="#anchor14"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor14header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor14header', true));
	if ( get_post_meta($post->ID, 'sh_anchor14header', true) ) 
	echo '</a></li>';

			
			// ANCHOR 15 LI
    if ( get_post_meta($post->ID, 'sh_anchor15header', true) )  
	echo '<li><a href="#anchor15"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor15header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor15header', true));
	if ( get_post_meta($post->ID, 'sh_anchor15header', true) ) 
	echo '</a></li>';

 
			// ANCHOR 16 LI
    if ( get_post_meta($post->ID, 'sh_anchor16header', true) )  
	echo '<li><a href="#anchor16"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor16header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor16header', true));
	if ( get_post_meta($post->ID, 'sh_anchor16header', true) ) 
	echo '</a></li>';


				// ANCHOR 17 LI
    if ( get_post_meta($post->ID, 'sh_anchor17header', true) )  
	echo '<li><a href="#anchor17"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor17header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor17header', true));
	if ( get_post_meta($post->ID, 'sh_anchor17header', true) ) 
	echo '</a></li>';

	
			// ANCHOR 18 LI
    if ( get_post_meta($post->ID, 'sh_anchor18header', true) )  
	echo '<li><a href="#anchor18"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor18header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor18header', true));
	if ( get_post_meta($post->ID, 'sh_anchor18header', true) ) 
	echo '</a></li>';

  
				// ANCHOR 19 LI
    if ( get_post_meta($post->ID, 'sh_anchor19header', true) )  
	echo '<li><a href="#anchor19"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor19header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor19header', true));
	if ( get_post_meta($post->ID, 'sh_anchor19header', true) ) 
	echo '</a></li>';

				
			// ANCHOR 20 LI
    if ( get_post_meta($post->ID, 'sh_anchor20header', true) )  
	echo '<li><a href="#anchor20"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor20header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor20header', true));
	if ( get_post_meta($post->ID, 'sh_anchor20header', true) ) 
	echo '</a></li>';

echo '</ul>';?>