<nav class="anchor-links">

<ul id="jump">


<?php 
		// ANCHOR 1 LI
    if ( get_post_meta($post->ID, 'sh_anchor1header', true) )  
	echo '<li class="anchor-links--itm"><a href="#anchor1" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor1header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor1header', true));
	if ( get_post_meta($post->ID, 'sh_anchor1header', true) ) 
	echo '</a></li>';
	
		// ANCHOR 2 LI
    if ( get_post_meta($post->ID, 'sh_anchor2header', true) )  
	echo '<li class="anchor-links--itm"><a href="#anchor2"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor2header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor2header', true));
	if ( get_post_meta($post->ID, 'sh_anchor2header', true) ) 
	echo '</a></li>';
	
			// ANCHOR 3 LI
    if ( get_post_meta($post->ID, 'sh_anchor3header', true) )  
	echo '<li class="anchor-links--itm"><a href="#anchor3"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor3header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor3header', true));
	if ( get_post_meta($post->ID, 'sh_anchor3header', true) ) 
	echo '</a></li>';

			// ANCHOR 4 LI
    if ( get_post_meta($post->ID, 'sh_anchor4header', true) )  
	echo '<li class="anchor-links--itm"><a href="#anchor4"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor4header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor4header', true));
	if ( get_post_meta($post->ID, 'sh_anchor4header', true) ) 
	echo '</a></li>';

			
			// ANCHOR 5 LI
    if ( get_post_meta($post->ID, 'sh_anchor5header', true) )  
	echo '<li class="anchor-links--itm"><a href="#anchor5"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor5header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor5header', true));
	if ( get_post_meta($post->ID, 'sh_anchor5header', true) ) 
	echo '</a></li>';

 
			// ANCHOR 6 LI
    if ( get_post_meta($post->ID, 'sh_anchor6header', true) )  
	echo '<li class="anchor-links--itm"><a href="#anchor6"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor6header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor6header', true));
	if ( get_post_meta($post->ID, 'sh_anchor6header', true) ) 
	echo '</a></li>';


				// ANCHOR 7 LI
    if ( get_post_meta($post->ID, 'sh_anchor7header', true) )  
	echo '<li class="anchor-links--itm"><a href="#anchor7"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor7header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor7header', true));
	if ( get_post_meta($post->ID, 'sh_anchor7header', true) ) 
	echo '</a></li>';

	
			// ANCHOR 8 LI
    if ( get_post_meta($post->ID, 'sh_anchor8header', true) )  
	echo '<li class="anchor-links--itm"><a href="#anchor8"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor8header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor8header', true));
	if ( get_post_meta($post->ID, 'sh_anchor8header', true) ) 
	echo '</a></li>';

  
				// ANCHOR 9 LI
    if ( get_post_meta($post->ID, 'sh_anchor9header', true) )  
	echo '<li class="anchor-links--itm"><a href="#anchor9"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor9header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor9header', true));
	if ( get_post_meta($post->ID, 'sh_anchor9header', true) ) 
	echo '</a></li>';

				
			// ANCHOR 10 LI
    if ( get_post_meta($post->ID, 'sh_anchor10header', true) )  
	echo '<li class="anchor-links--itm"><a href="#anchor10"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor10header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor10header', true));
	if ( get_post_meta($post->ID, 'sh_anchor10header', true) ) 
	echo '</a></li>';
	
	// ANCHOR 11 LI
    if ( get_post_meta($post->ID, 'sh_anchor11header', true) )  
	echo '<li class="anchor-links--itm"><a href="#anchor11"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor11header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor11header', true));
	if ( get_post_meta($post->ID, 'sh_anchor11header', true) ) 
	echo '</a></li>';
	
		// ANCHOR 12 LI
    if ( get_post_meta($post->ID, 'sh_anchor12header', true) )  
	echo '<li class="anchor-links--itm"><a href="#anchor12"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor12header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor12header', true));
	if ( get_post_meta($post->ID, 'sh_anchor12header', true) ) 
	echo '</a></li>';
	
			// ANCHOR 13 LI
    if ( get_post_meta($post->ID, 'sh_anchor13header', true) )  
	echo '<li class="anchor-links--itm"><a href="#anchor13"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor13header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor13header', true));
	if ( get_post_meta($post->ID, 'sh_anchor13header', true) ) 
	echo '</a></li>';

			// ANCHOR 14 LI
    if ( get_post_meta($post->ID, 'sh_anchor14header', true) )  
	echo '<li class="anchor-links--itm"><a href="#anchor14"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor14header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor14header', true));
	if ( get_post_meta($post->ID, 'sh_anchor14header', true) ) 
	echo '</a></li>';

			
			// ANCHOR 15 LI
    if ( get_post_meta($post->ID, 'sh_anchor15header', true) )  
	echo '<li class="anchor-links--itm"><a href="#anchor15"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor15header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor15header', true));
	if ( get_post_meta($post->ID, 'sh_anchor15header', true) ) 
	echo '</a></li>';

 
			// ANCHOR 16 LI
    if ( get_post_meta($post->ID, 'sh_anchor16header', true) )  
	echo '<li class="anchor-links--itm"><a href="#anchor16"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor16header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor16header', true));
	if ( get_post_meta($post->ID, 'sh_anchor16header', true) ) 
	echo '</a></li>';


				// ANCHOR 17 LI
    if ( get_post_meta($post->ID, 'sh_anchor17header', true) )  
	echo '<li class="anchor-links--itm"><a href="#anchor17"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor17header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor17header', true));
	if ( get_post_meta($post->ID, 'sh_anchor17header', true) ) 
	echo '</a></li>';

	
			// ANCHOR 18 LI
    if ( get_post_meta($post->ID, 'sh_anchor18header', true) )  
	echo '<li class="anchor-links--itm"><a href="#anchor18"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor18header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor18header', true));
	if ( get_post_meta($post->ID, 'sh_anchor18header', true) ) 
	echo '</a></li>';

  
				// ANCHOR 19 LI
    if ( get_post_meta($post->ID, 'sh_anchor19header', true) )  
	echo '<li class="anchor-links--itm"><a href="#anchor19"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor19header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor19header', true));
	if ( get_post_meta($post->ID, 'sh_anchor19header', true) ) 
	echo '</a></li>';

				
			// ANCHOR 20 LI
    if ( get_post_meta($post->ID, 'sh_anchor20header', true) )  
	echo '<li class="anchor-links--itm"><a href="#anchor20"class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> ';
	if ( get_post_meta($post->ID, 'sh_anchor20header', true) ) 
	echo do_shortcode (get_post_meta($post->ID, 'sh_anchor20header', true));
	if ( get_post_meta($post->ID, 'sh_anchor20header', true) ) 
	echo '</a></li>';

?>

</ul>
</nav>



<?php 

	// ************* ANCHOR 1 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor1', true) )   
		echo'<div class="anchor"><a id="anchor1"></a>';
		
		if ( get_post_meta($post->ID, 'sh_anchor1header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor1header', true));
		if ( get_post_meta($post->ID, 'sh_anchor1header', true) )  
		echo '</h2>'; 
		
		
		if ( get_post_meta($post->ID, 'sh_anchor1', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor1', true));
		// set the scrollable area content
   			if ( get_post_meta($post->ID, 'sh_anchor1', true) )   
			echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';

	// ************* ANCHOR 2 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor2', true) )   
		echo'<div class="anchor"><a id="anchor2"></a>';	
			
		if ( get_post_meta($post->ID, 'sh_anchor2header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor2header', true));
		if ( get_post_meta($post->ID, 'sh_anchor2header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor2', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor2', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor2', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 3 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor3', true) )   
		echo'<div class="anchor"><a id="anchor3"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor3header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor3header', true));
		if ( get_post_meta($post->ID, 'sh_anchor3header', true) )  
		echo '</h2>'; 
		
		
		if ( get_post_meta($post->ID, 'sh_anchor3', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor3', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor3', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 4 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor4', true) )   
		echo'<div class="anchor"><a id="anchor4"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor4header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor4header', true));
		if ( get_post_meta($post->ID, 'sh_anchor4header', true) )  
		echo '</h2>'; 
		
		
		
		if ( get_post_meta($post->ID, 'sh_anchor4', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor4', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor4', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 5 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor5', true) )   
		echo'<div class="anchor"><a id="anchor5"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor5header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor5header', true));
		if ( get_post_meta($post->ID, 'sh_anchor5header', true) )  
		echo '</h2>'; 
		
		
		if ( get_post_meta($post->ID, 'sh_anchor5', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor5', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor5', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 6 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor6', true) )   
		echo'<div class="anchor"><a id="anchor6"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor6header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor6header', true));
		if ( get_post_meta($post->ID, 'sh_anchor6header', true) )  
		echo '</h2>'; 
		
		
		if ( get_post_meta($post->ID, 'sh_anchor6', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor6', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor6', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 7 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor7', true) )   
		echo'<div class="anchor"><a id="anchor7"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor7header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor7header', true));
		if ( get_post_meta($post->ID, 'sh_anchor7header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor7', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor7', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor7', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 8 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor8', true) )   
		echo'<div class="anchor"><a id="anchor8"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor8header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor8header', true));
		if ( get_post_meta($post->ID, 'sh_anchor8header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor8', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor8', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor8', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 9 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor9', true) )   
		echo'<div class="anchor"><a id="anchor9"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor9header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor9header', true));
		if ( get_post_meta($post->ID, 'sh_anchor9header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor9', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor9', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor9', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 10 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor10', true) )   
		echo'<div class="anchor"><a id="anchor10"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor10header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor10header', true));
		if ( get_post_meta($post->ID, 'sh_anchor10header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor10', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor10', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor10', true) )   echo'</div><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a>';
		
			// ************* ANCHOR 11 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor11', true) )   
		echo'<div class="anchor"><a id="anchor11"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor11header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor11header', true));
		if ( get_post_meta($post->ID, 'sh_anchor11header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor11', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor11', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor11', true) )   echo'</div><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a>';
		
			// ************* ANCHOR 12 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor12', true) )   
		echo'<div class="anchor"><a id="anchor12"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor12header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor12header', true));
		if ( get_post_meta($post->ID, 'sh_anchor12header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor12', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor12', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor12', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 13 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor13', true) )   
		echo'<div class="anchor"><a id="anchor13"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor13header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor13header', true));
		if ( get_post_meta($post->ID, 'sh_anchor13header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor13', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor13', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor13', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 14 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor14', true) )   
		echo'<div class="anchor"><a id="anchor14"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor14header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor14header', true));
		if ( get_post_meta($post->ID, 'sh_anchor14header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor14', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor14', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor14', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 15 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor15', true) )   
		echo'<div class="anchor"><a id="anchor15"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor15header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor15header', true));
		if ( get_post_meta($post->ID, 'sh_anchor15header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor15', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor15', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor15', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 16 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor16', true) )   
		echo'<div class="anchor"><a id="anchor16"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor16header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor16header', true));
		if ( get_post_meta($post->ID, 'sh_anchor16header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor16', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor16', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor16', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 170 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor17', true) )   
		echo'<div class="anchor"><a id="anchor17"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor17header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor17header', true));
		if ( get_post_meta($post->ID, 'sh_anchor17header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor17', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor17', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor17', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 18 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor18', true) )   
		echo'<div class="anchor"><a id="anchor18"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor18header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor18header', true));
		if ( get_post_meta($post->ID, 'sh_anchor18header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor18', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor18', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor18', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 19 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor19', true) )   
		echo'<div class="anchor"><a id="anchor19"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor19header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor19header', true));
		if ( get_post_meta($post->ID, 'sh_anchor19header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor19', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor19', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor19', true) )   echo'</div><div class="backtotopscroll"><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a></div>';
		
			// ************* ANCHOR 20 **********
 //set anchor id   	
		if ( get_post_meta($post->ID, 'sh_anchor20', true) )   
		echo'<div class="anchor"><a id="anchor20"></a>';
		
				
		if ( get_post_meta($post->ID, 'sh_anchor20header', true) )  
		echo '<h2>'; echo do_shortcode (get_post_meta($post->ID, 'sh_anchor20header', true));
		if ( get_post_meta($post->ID, 'sh_anchor20header', true) )  
		echo '</h2>'; 
		
		if ( get_post_meta($post->ID, 'sh_anchor20', true) )  
		echo do_shortcode (get_post_meta($post->ID, 'sh_anchor20', true));
		// set the scrollable area content
   		if ( get_post_meta($post->ID, 'sh_anchor20', true) )   echo'</div><a href="#top" class="scroll"><span class="wpjb-glyphs wpjb-icon-right-open"></span> back to top</a>';
		
	?>		