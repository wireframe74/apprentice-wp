<div id="topmenucontainer"> <ul id="topmenu"><li><a href="/all-jobs/">Current Vacancies</a></li><li><a href="/apply">Sign In</a></li><li><a href="/policies/">Policies</a></li><li><a href="/contact/">Contact</a></li><li style="padding:0px!important"><a href="https://www.facebook.com/AiGroupATC/" target="_blank"><img src="<?php bloginfo('url' ); ?>/wp-content/uploads/fb-logo.png" border="0" width="25" alt="Find us on Facebook" title="Find us on Facebook"></a></ul> 

<div class="aigwd-search">
   
  
  <form action="<?php bloginfo('siteurl'); ?>" id="searchform" method="get">
 <div class="searchcontainer">
 <input type="text" value="" name="s" id="s" placeholder="Search"'. $onfocus . $onblur .' />
 <input type="submit"  id="searchsubmit" value="Search" /></div>
</form>
</div></div>
