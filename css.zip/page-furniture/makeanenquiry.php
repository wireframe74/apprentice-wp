<div id="makeanenquiry">
<h2>MAKE AN ENQUIRY</h2>
<?php echo do_shortcode("[contact-form-7 id=74 title=MAKE AN ENQUIRY]"); ?>
 </div>