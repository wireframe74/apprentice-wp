<div id="makeanenquiry">
<h2>APPLICATION FORM</h2>
<?php echo do_shortcode("[contact-form-7 id=\"643\" title=\"Application Form\"]"); ?>
 </div>