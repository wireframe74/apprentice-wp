   
 <a href="/register/">Register</a> | <a href="/register/">Sign In</a> 